================AVI4BMP=============
Animations to BMP/PNG grid converter
Absolutely Freeware
(C)2005 Bottomap Software

====================================

Avi4Bmp is mainly a conversion tool which reads Avi,Gif and Mpgs and converts them to an unique Bmp or Png with all frames from the original animation. 

Really handy for game programming. Convert-back feature allow the user to get back the original animation after, for example, the application of filters or retouch (AVI back conversion is subjected to usual rules according to codecs used - uncompressed Avi will however be always converted back).

Perfect for BlitzBasic's LoadAnimImage() function as well as other game developing software which read animated images from a strip or a grid.
Full Drag and Drop support and limited size (160kb) make it an handy tool for every game-programmer.

Since it's an open project everyone is invited to make suggestion or ask for their-preferite-file-format's integration ;-)

By Bottomap Software

Release 25.Oct.2007 v2.4 - Added 8bit PNG support.
Release 24.Jun.2005 v2.3 - Corrected odd behaving on GIF first frame.
Release 14.Mar.2005 v2.2 - Added MPG/AVI Full integration.

LICENSE:
=====================================

Avi4Bmp (A4B) is freeware. This means:

- All copyrights to A4B are exclusively owned by Bottomap Software.

- A4B may be freely distributed, provided the distribution 
  package is not modified. No person or company may charge 
  a fee for the distribution of A4B without written permission 
  from the copyright holder.

- A4B IS DISTRIBUTED "AS IS".  NO WARRANTY OF ANY KIND IS
  EXPRESSED OR IMPLIED.  YOU USE AT YOUR OWN RISK.  THE AUTHOR
  WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR
  ANY OTHER KIND OF LOSS WHILE USING OR MISUSING THIS SOFTWARE.

- Installing and using A4B signifies you accept these terms
  and conditions of the license.

- If you do not agree with the terms of this license you must remove
  A4B files from your storage devices and cease to use the product.

PLEASE CONTACT!
=======================================
If you like or dislike this program feel free to write us your impressions at: info@bottomap.com
If you find bugs or encounter problems running this utility please report at: support@bottomap.com

Visit us at:
http://www.bottomap.com/

...or just search "Bottomap" on Google...
